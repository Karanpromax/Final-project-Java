package com.voting.servlet;

import com.voting.dao.VoterDAO;
import com.voting.model.Voter;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet(name = "RegisterServlet", urlPatterns = {"/register"})
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String aadhaar = request.getParameter("aadhaar");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Voter v = new Voter();
        v.setName(name);
        v.setAadhaar(aadhaar);
        v.setEmail(email);
        v.setPassword(password);

        VoterDAO dao = new VoterDAO();
        boolean ok = dao.registerVoter(v);
        if (ok) {
            response.sendRedirect("login.jsp");
        } else {
            request.setAttribute("error", "Registration failed");
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
    }
}
