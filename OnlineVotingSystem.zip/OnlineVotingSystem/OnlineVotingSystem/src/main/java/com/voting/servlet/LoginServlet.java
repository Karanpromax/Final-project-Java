package com.voting.servlet;

import java.io.IOException;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import com.voting.dao.VoterDAO;
import com.voting.model.Voter;

public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        VoterDAO dao = new VoterDAO();
        Voter voter = dao.login(email, password);

        if (voter != null) {
            HttpSession session = request.getSession();
            session.setAttribute("voter", voter);
            response.sendRedirect("vote.jsp");
        } else {
            response.sendRedirect("login.jsp?error=Invalid email or password");
        }
    }
}
