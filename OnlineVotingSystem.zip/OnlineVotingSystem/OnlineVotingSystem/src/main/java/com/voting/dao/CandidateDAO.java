package com.voting.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.voting.model.Candidate;
import com.voting.util.DBConnection;

public class CandidateDAO {

    // Add candidate
    public boolean addCandidate(Candidate candidate) {
        boolean status = false;
        try {
            Connection con = DBConnection.getConnection();
            String query = "INSERT INTO candidates (name, party, votes) VALUES (?, ?, 0)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, candidate.getName());
            ps.setString(2, candidate.getParty());
            int rows = ps.executeUpdate();
            if (rows > 0) status = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    // Get all candidates
    public List<Candidate> getAllCandidates() {
        List<Candidate> list = new ArrayList<>();
        try {
            Connection con = DBConnection.getConnection();
            String query = "SELECT * FROM candidates";
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Candidate c = new Candidate();
                c.setId(rs.getInt("id"));
                c.setName(rs.getString("name"));
                c.setParty(rs.getString("party"));
                list.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // ✅ Added method to increment candidate's vote count
    public void addVote(int candidateId) {
        try {
            Connection con = DBConnection.getConnection();
            String query = "UPDATE candidates SET votes = votes + 1 WHERE id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, candidateId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
