// ✅ Updated login() returns a Voter object, not boolean
public Voter login(String email, String password) {
    Voter voter = null;
    try {
        Connection con = DBConnection.getConnection();
        String query = "SELECT * FROM voters WHERE email=? AND password=?";
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1, email);
        ps.setString(2, password);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            voter = new Voter();
            voter.setId(rs.getInt("id"));
            voter.setName(rs.getString("name"));
            voter.setEmail(rs.getString("email"));
            voter.setPassword(rs.getString("password"));
            voter.setHasVoted(rs.getBoolean("has_voted"));
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return voter;
}
