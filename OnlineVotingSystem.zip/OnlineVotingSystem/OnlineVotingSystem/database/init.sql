-- Create Database
CREATE DATABASE IF NOT EXISTS online_voting;
USE online_voting;

-- Table: voters
CREATE TABLE IF NOT EXISTS voters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    has_voted BOOLEAN DEFAULT 0
);

-- Table: candidates
CREATE TABLE IF NOT EXISTS candidates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    party VARCHAR(100) NOT NULL,
    votes INT DEFAULT 0
);

-- Table: votes
CREATE TABLE IF NOT EXISTS votes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    voter_id INT,
    candidate_id INT,
    FOREIGN KEY (voter_id) REFERENCES voters(id),
    FOREIGN KEY (candidate_id) REFERENCES candidates(id)
);

-- Sample Data (optional)
INSERT INTO candidates (name, party) VALUES
('Alice Johnson', 'Party A'),
('Bob Singh', 'Party B'),
('Carol Verma', 'Party C');
