package com.voting.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.voting.util.DBConnection;

public class VoteDAO {

    // Cast a vote
    public boolean castVote(int voterId, int candidateId) {
        boolean status = false;
        try {
            Connection con = DBConnection.getConnection();
            String query = "INSERT INTO votes (voter_id, candidate_id) VALUES (?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, voterId);
            ps.setInt(2, candidateId);
            int rows = ps.executeUpdate();
            if (rows > 0) status = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    // ✅ Added method to mark that a voter has voted
    public void markVoted(int voterId) {
        try {
            Connection con = DBConnection.getConnection();
            String query = "UPDATE voters SET has_voted = 1 WHERE id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, voterId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Count votes
    public int countVotes(int candidateId) {
        int count = 0;
        try {
            Connection con = DBConnection.getConnection();
            String query = "SELECT COUNT(*) FROM votes WHERE candidate_id=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, candidateId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) count = rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }
}
