package com.voting.servlet;

import com.voting.dao.CandidateDAO;
import com.voting.dao.VoteDAO;
import com.voting.model.Voter;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet(name = "VoteServlet", urlPatterns = {"/vote"})
public class VoteServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null) { response.sendRedirect("login.jsp"); return; }

        Voter voter = (Voter) session.getAttribute("voter");
        if (voter == null) { response.sendRedirect("login.jsp"); return; }

        String cid = request.getParameter("candidate_id");
        if (cid == null) { response.sendRedirect("vote.jsp"); return; }

        int candidateId = Integer.parseInt(cid);
        CandidateDAO cdao = new CandidateDAO();
        VoteDAO vdao = new VoteDAO();

        boolean voted = cdao.addVote(candidateId);
        boolean marked = vdao.markVoted(voter.getVoterId());

        if (voted && marked) {
            session.removeAttribute("voter");
            response.sendRedirect("result.jsp");
        } else {
            request.setAttribute("error", "Unable to cast vote. Try again.");
            request.getRequestDispatcher("vote.jsp").forward(request, response);
        }
    }
}
